import { AlertTriangle } from 'lucide-react';


type Severity = 'high' | 'med' | 'low';

interface Incident {
  id: string;
  title: string;
  severity: Severity;
}

const MOCK_STATS = { active: 12, critical: 3, resolved: 47 };

const MOCK_INCIDENTS: Incident[] = [
  { id: 'INC-2841', title: 'Fire alert · Sector 7', severity: 'high' },
  { id: 'INC-2840', title: 'Traffic · MainSt junction', severity: 'med' },
  { id: 'INC-2839', title: 'Power surge · Grid 04', severity: 'low' },
];

const SEVERITY_STYLES: Record<Severity, { label: string; className: string }> = {
  high: { label: 'HIGH', className: 'bg-red-500 text-red-950' },
  med: { label: 'MED', className: 'border border-amber-500 text-amber-500' },
  low: { label: 'LOW', className: 'border border-aman-blue text-aman-light' },
};

export function ActiveIncidentsPanel() {
  return (
    <div className="h-full flex flex-col rounded-xl border border-aman-teal bg-aman-dark px-4 py-3.5 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between mb-3.5 shrink-0">
        <div className="flex items-center gap-2">
          <div className="h-6.5 w-6.5 rounded-md bg-aman-teal flex items-center justify-center">
            <AlertTriangle className="h-3.5 w-3.5 text-aman-light" />
          </div>
          <span className="text-[13px] font-medium tracking-wide text-aman-white">
            ACTIVE INCIDENTS
          </span>
        </div>
        <span className="flex items-center gap-1.5 text-[11px] tracking-wider text-red-500">
          <span className="h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse" />
          LIVE
        </span>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2 mb-3.5 shrink-0">
        <Stat label="ACTIVE" value={MOCK_STATS.active} className="text-amber-500" />
        <Stat label="CRITICAL" value={MOCK_STATS.critical} className="text-red-500" />
        <Stat label="RESOLVED" value={MOCK_STATS.resolved} className="text-emerald-400" />
      </div>

      {/* Incident list — scrolls internally if it ever exceeds the card's
          slot height, so it never pushes the page (which never scrolls). */}
      <div className="flex flex-col gap-2 overflow-y-auto min-h-0">
        {MOCK_INCIDENTS.map((incident) => (
          <IncidentRow key={incident.id} incident={incident} />
        ))}
      </div>
    </div>
  );
}

function Stat({ label, value, className }: { label: string; value: number; className: string }) {
  return (
    <div>
      <p className="text-[10px] tracking-wider text-aman-blue mb-1">{label}</p>
      <p className={`text-[22px] font-medium leading-none ${className}`}>{value}</p>
    </div>
  );
}

function IncidentRow({ incident }: { incident: Incident }) {
  const badge = SEVERITY_STYLES[incident.severity];
  return (
    <div className="rounded-lg bg-aman-teal px-3 py-2">
      <div className="flex items-center justify-between mb-1">
        <span className="text-[10px] text-aman-blue">{incident.id}</span>
        <span className={`text-[10px] font-medium px-2 py-0.5 rounded ${badge.className}`}>
          {badge.label}
        </span>
      </div>
      <p className="text-[13px] text-aman-white">{incident.title}</p>
    </div>
  );
}